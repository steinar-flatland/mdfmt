# Line Endings

This file has either Unix or Windows style line endings.

Here is a bulleted list:

- one
- two
- three
- four
- five
- six
- seven
- eight
- nine
- ten
