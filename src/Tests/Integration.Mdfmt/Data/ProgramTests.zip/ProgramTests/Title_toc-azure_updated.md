# Scenario: Updating An Outdated TOC

<!--BEGIN_TOC-->
- [Scenario: Updating An Outdated TOC](./file.md#scenario:-updating-an-outdated-toc)
  - [1. Introduction](./file.md#1.-introduction)
  - [2. Good Stuff](./file.md#2.-good-stuff)
  - [Here's An Extra Section](./file.md#here's-an-extra-section)
  - [3. Conclusion](./file.md#3.-conclusion)
<!--END_TOC-->

## 1. Introduction

## 2. Good Stuff

## Here's An Extra Section

## 3. Conclusion
