# Mixed Line Endings

This file has mixed line endings.

At the top of the file, the lines are terminated in the Windows style with `\r\n`.

However, within the bulleted list below, the Unix style of `\n` is used.

Here is a bulleted list:

- one
- two
- three
- four
- five
- six
- seven
- eight
- nine
- ten
