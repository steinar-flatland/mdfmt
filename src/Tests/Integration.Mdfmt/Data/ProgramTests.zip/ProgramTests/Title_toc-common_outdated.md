# Scenario: Updating An Outdated TOC

<!--BEGIN_TOC-->
- [Scenario: Updating An Outdated TOC](#scenario-updating-an-outdated-toc)
  - [1. Introduction](#1-introduction)
  - [2. Good Stuff](#2-good-stuff)
  - [3. Conclusion](#3-conclusion)
<!--END_TOC-->

## 1. Introduction

## 2. Good Stuff

## Here's An Extra Section

## 3. Conclusion
