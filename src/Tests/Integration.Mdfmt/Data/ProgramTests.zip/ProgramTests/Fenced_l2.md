# Fenced Code Block Test

This file (and related files) used to test switching from one line numbering threshold value to another.  This causes line numbers in different blocks to be added or deleted, as appropriate for the new threshold.

A one liner:

```bash
ls -l
```

Two lines:

```bash
1 ls -l
2 dir
```

Three lines:

```Markdown
1 # Title
2 ## Heading 1
3 ### Heading 2
```
