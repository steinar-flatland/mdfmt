# README

This folder contains Markdown files to support integration testing of Mdfmt.  These files are copied to the bin directory, so they are available to `Integration.Mdfmt` at test execution time.

These files are read from but not written to to support the testing strategy.
