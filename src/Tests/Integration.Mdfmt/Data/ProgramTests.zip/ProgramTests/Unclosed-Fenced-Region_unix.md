# Unclosed Fenced Region

This file has an unclosed fenced region.

Mdfmt should still be able to load the content below as a fenced code block.

```Csharp
    public static void Main(string[] args)
    {
        try
        {
            RunProgram(args);
        }
        catch (Exception ex)
        {
            LogException(ex);
        }
    }