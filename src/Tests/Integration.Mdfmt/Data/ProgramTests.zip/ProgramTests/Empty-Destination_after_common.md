# Empty Destination Test

<!--BEGIN_TOC-->
- [Empty Destination Test](#empty-destination-test)
  - [1. Introduction](#1-introduction)
  - [2. Cool Stuff](#2-cool-stuff)
  - [3. Enigmatic Stuff](#3-enigmatic-stuff)
  - [4. Conclusion](#4-conclusion)
<!--END_TOC-->

## 1. Introduction

This test proves that if a destination is empty, Mdfmt will try to fill it in by matching it to a heading.

To read about cool stuff go to section [2. Cool Stuff](#2-cool-stuff).

To read about enigmatic stuff go to section [3. Enigmatic Stuff](#3-enigmatic-stuff).

Try as we might, this link cannot be resolved:  [Nonexistent Stuff]().  It will remain with an empty destination.

## 2. Cool Stuff

This is a section on cool stuff.

## 3. Enigmatic Stuff

This is a section on Enigmatic Stuff.

## 4. Conclusion

That's all.
