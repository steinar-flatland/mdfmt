# Test of Adding TOC With Mixed Line Endings

## Introduction

This is a test of adding a TOC with mixed line endings.

The TOC should use the style of line ending that is the most common within the file.

## Lists

### List of States

Note: After each state name if a newline that is a different style from the rest of the file.

- Alabama
- Louisiana
- New York

### List of Fictional Characters

- David Coperfield
- Oliver Twist
- Bill Sikes
