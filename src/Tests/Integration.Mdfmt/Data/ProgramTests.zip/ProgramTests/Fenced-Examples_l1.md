# Fenced Code Block Examples

<!--BEGIN_TOC-->
- [Fenced Code Block Examples](#fenced-code-block-examples)
  - [Empty Code Block](#empty-code-block)
  - [One Liner That Is Empty Line](#one-liner-that-is-empty-line)
  - [Nontrivial Code Block](#nontrivial-code-block)
  - [Code Block With Many Empty Lines](#code-block-with-many-empty-lines)
  - [Weirdly Numbered 1](#weirdly-numbered-1)
  - [Weirdly Numbered 2](#weirdly-numbered-2)
  - [Weirdly Numbered 3](#weirdly-numbered-3)
  - [Weirdly Numbered 4](#weirdly-numbered-4)
  - [Already Numbered 1](#already-numbered-1)
  - [Already Numbered 2](#already-numbered-2)
  - [Already Numbered Empty Lines](#already-numbered-empty-lines)
<!--END_TOC-->

## Empty Code Block

```Csharp
```

## One Liner That Is Empty Line

```C
1
```

## Nontrivial Code Block

```csharp
 1     /// <summary>
 2     /// <para>
 3     /// Returns all the <em>left paths</em> of the path passed in, in descending length order.  A
 4     /// <em>left path</em> is a path that is rooted on the left but may have 0 or more path
 5     /// segments chopped off on the right.
 6     /// </para>
 7     /// <para>
 8     /// <b>Example:</b> <c>path == "./foo/bar/baz.md"</c>
 9     /// <list type="number">
10     /// <item><c>./foo/bar/baz.md</c></item>
11     /// <item><c>./foo/bar</c></item>
12     /// <item><c>./foo</c></item>
13     /// <item><c>.</c></item>
14     /// </list>
15     /// </para>
16     /// </summary>
17     /// <param name="path">A path</param>
18     /// <returns>IEnumerable for getting all of the left paths of the path.</returns>
19     public static IEnumerable<string> LeftPaths(string path)
20     {
21         string currentPath = path;
22         while (!string.IsNullOrEmpty(currentPath))
23         {
24             yield return currentPath.Replace('\\', '/');
25             currentPath = Path.GetDirectoryName(currentPath) ?? ".";
26         }
27     }
```

## Code Block With Many Empty Lines

```bash
 1
 2
 3
 4 ls -l
 5
 6
 7 ps -ef | grep foo
 8
 9
10
11
12  
13
```

Note that that the penultimate line of the code block has a single space rather than being blank, just to mix it up.

## Weirdly Numbered 1

```Csharp
1 1 // A silly piece of code
2 2 for (int i = 0; i < 10; i++)
3 4 {
4 5     Console.WriteLine($"Hello number {i+1}");
5 6 }
```

Because the "line numbers" are not sequential, Mdfmt does not treat these as line numbers.

## Weirdly Numbered 2

```Csharp
1 0 // A silly piece of code
2 1 for (int i = 0; i < 10; i++)
3 2 {
4 3     Console.WriteLine($"Hello number {i+1}");
5 4 }
```

Because the "line numbers" are not 1-based, Mdfmt does not treat these as line numbers.

## Weirdly Numbered 3

```Csharp
1 1 // A silly piece of code
2 2 for (int i = 0; i < 10; i++)
3 3 {
4 4     Console.WriteLine($"Hello number {i+1}");
5   }
```

## Weirdly Numbered 4

```Csharp
1 1// A silly piece of code
2 2for (int i = 0; i < 10; i++)
3 3{
4 4    Console.WriteLine($"Hello number {i+1}");
5 5}
```

Because the "line numbers" are jammed up against the content without a space separator, Mdfmt does not treat these as line numbers.

## Already Numbered 1

```Csharp
1 // A silly piece of code
2 for (int i = 0; i < 10; i++)
3 {
4     Console.WriteLine($"Hello number {i+1}");
5 }
```

This example has actual line numbers.  Turning line numbering on should not change it.

## Already Numbered 2

```Csharp
 1     // A silly piece of code
  2    for (int i = 0; i < 10; i++)
   3   {
    4     Console.WriteLine($"Hello number {i+1}");
     5 }
```

If the code is already numbered, Mdfmt respects the whitespace, even if it is strange.  Turning line numbering on should not edit this code block.

## Already Numbered Empty Lines

```text
1
2
3
4
5
6
7
8
9
10
```

If there's no content on a line other than a line number, Mdfmt does recognize these as line numbers.
